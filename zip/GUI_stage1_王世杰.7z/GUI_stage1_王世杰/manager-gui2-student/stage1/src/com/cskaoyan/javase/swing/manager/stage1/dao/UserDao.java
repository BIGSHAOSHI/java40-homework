package com.cskaoyan.javase.swing.manager.stage1.dao;

import com.cskaoyan.javase.swing.manager.stage1.model.User;
import com.cskaoyan.javase.swing.manager.stage1.model.UserData;

/**
 * 与管理员用户相关的，所有数据处理都在该类下进行
 *
 * @author wuguidong@cskaoyan.onaliyun.com
 * @since 19:36
 */
public class UserDao {

    // 从数据源获取数据
    // USERS[0] = new User("admin", "admin");
    // USERS[1] = new User("root", "root");
    private User[] users = UserData.USERS;


    public boolean isNameExist(User user) {
        for (int i = 0; i < this.users.length && this.users[i] != null; i++) {
            if (user.getUsername().equals(this.users[i].getUsername())) {
                return true;
            }
        }
        return false;
    }

    public boolean isPasswordTrue(User user) {
        int index = -1;
        for (int i = 0; i < this.users.length && this.users[i] != null; i++) {
            if (user.getUsername().equals(this.users[i].getUsername())) {
                index = i;
            }
        }
        if (index >= 0 && user.getPassword().equals(this.users[index].getPassword())) {
            return true;
        }
        return false;
    }
}
