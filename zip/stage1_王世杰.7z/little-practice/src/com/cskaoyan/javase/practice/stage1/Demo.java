package com.cskaoyan.javase.practice.stage1;

import java.util.Scanner;

public class Demo {

    private static void showMethod() {
        System.out.println("------------王道Java学生管理系统------------");
        System.out.println("             1.学 生 列 表");
        System.out.println("             2.增 加 学 生");
        System.out.println("             3.删 除 学 生");
        System.out.println("             4.修 改 学 生");
        System.out.println("             5.查 询 学 生");
        System.out.println("             6.退 出 系 统");
        System.out.println("请选择功能(1~6):");
    }

    public static void method1() {

    }

    public static void method2() {

    }

    public static void method3() {

    }

    public static void method4() {

    }

    public static void method5() {

    }

    private static boolean method6(Scanner scanner) {
        System.out.println("确认退出吗(1/2):");
        int function2 = scanner.nextInt();
        if (function2 == 1) {
            System.out.println("正在退出中！");
            return true;
        }
        return false;
    }

    public static void stage1() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            showMethod();
            int function = scanner.nextInt();
            if (function == 1) {
            } else if (function == 2) {
            } else if (function == 3) {
            } else if (function == 4) {
            } else if (function == 5) {
            } else if (function == 6) {
                if (method6(scanner)) break;
            }
        }
    }

    public static void main(String[] args) {
        stage1();
    }
}